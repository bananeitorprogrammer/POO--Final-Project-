/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Bebidas {
    //atributos 
    private String nombre; 
    private double precio;
    private boolean alcohol;
    
    //Constructor
    public Bebidas(String nombre, double precio, boolean alcohol) {
        this.nombre = nombre;
        this.precio = precio;
        this.alcohol = alcohol;
    }
    
    public void preparar_bebida(){
        System.out.println("Inciiando preparacion de la bebida...");
        System.out.println("El platillo: "+this.nombre+" incia su preparación");
        try{
            Thread.sleep(500);
        }catch (InterruptedException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println(" ---------PEDIDO LISTO---------"+this.nombre);
    }
}
