/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Empleados implements Runnable {
    //Constructor
    private int numero_emp;
    private String nombre_empleado;
    private String tipo_empleado;
    Platillos platillo;
    
    //Constructor 

    public Empleados(int numero_emp, String nombre_empleado, Platillos platillo) {
        this.numero_emp = numero_emp;
        this.nombre_empleado = nombre_empleado;
        this.tipo_empleado=tipo_empleado;
        this.platillo = platillo;
    }
    
    public void run(){
        System.out.println(nombre_empleado + " recibe el platillo: "+platillo);
        platillo.preparar();
        System.out.println("Entrega el pedido");
    }
    
}
