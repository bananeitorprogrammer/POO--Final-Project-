/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Entrada extends Platillos{
    //Atributos
    private boolean aderezo;
    private String tamano;
    
    //Constructor
    public Entrada(String nombre, double precio, int tiempo_prep, boolean aderezo, String tamano) {
        super(nombre, precio, tiempo_prep);
        this.aderezo=aderezo;
        this.tamano=tamano;
    }
    
    //Sobre-esritura de metodos 

    @Override
    public synchronized void preparar() {
        super.preparar(); 
        System.out.println("-----DESCRIPCION DE ENTRADA---------");
        System.out.println("Entrada: "+getNombre());
        System.out.println("Aderezo: "+aderezo);
        System.out.println("Tamano: "+tamano);
    }
    
}
