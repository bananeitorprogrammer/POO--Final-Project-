/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Plato_fuerte extends Platillos{
    //Atributos 
    private int temperatura_inter;
    private int calorias;
    private boolean guarnicon;
    
    //Construtcor 
    public Plato_fuerte(String nombre, double precio, int tiempo_prep, int temperatura_int,int calorias, boolean guarnicon) {
        super(nombre, precio, tiempo_prep);
        this.calorias=calorias;
        this.temperatura_inter=temperatura_inter;
        this.guarnicon=guarnicon;
    }
    
    public synchronized void preparar() {
        super.preparar(); 
        System.out.println("-----DESCRIPCION DE PLATO FUERTE---------");
        System.out.println("Entrada: "+getNombre());
        System.out.println("Guarnicion: "+guarnicon);
        System.out.println("Temperatura interna: "+temperatura_inter);
    }
}
