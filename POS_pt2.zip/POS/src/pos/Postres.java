/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Postres extends Platillos{
    //Atributos propios 
    private boolean caliente;
    private String textura;
    private String sabor;
    
    //Constructor 
    public Postres(String nombre, double precio, int tiempo_prep, boolean caliente, String textura, String sabor) {
        super(nombre, precio, tiempo_prep);
        this.caliente=caliente;
        this.textura=textura;
        this.sabor=sabor;
    }
    
    //Sobre-escritura de metodos  
    public synchronized void preparar() {
        super.preparar(); 
        System.out.println("-----DESCRIPCION DEL POSTER---------");
        System.out.println("Entrada: "+getNombre());
        System.out.println("Textura: "+textura);
        System.out.println("Sabor: "+sabor);
    }
}
