/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Bebidas {
    //atributos 
    private String nombre; 
    private double precio;
    private boolean alcohol;
    
    //Constructor
    public Bebidas(String nombre, double precio, boolean alcohol) {
        this.nombre = nombre;
        this.precio = precio;
        this.alcohol = alcohol;
    }
}
