/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos;

/**
 *
 * @author anapa
 */
public class Platillos {
    //Atributos de la clase 
    private String nombre;
    private double precio;
    private int tiempo_prep;
    
    //Constructor
    public Platillos(String nombre, double precio, int tiempo_prep) {
        this.nombre = nombre;
        this.precio = precio;
        this.tiempo_prep = tiempo_prep;
    }
    
    //gets 

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getTiempo_prep() {
        return tiempo_prep;
    }
    
    
    //metodo preparar 
    public synchronized void preparar(){
        System.out.println("Inciiando preparacion del platillo...");
        System.out.println("El platillo: "+this.nombre+" incia su preparación");
        try{
            Thread.sleep(this.tiempo_prep);
        }catch (InterruptedException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println(" ---------PEDIDO LISTO---------"+this.nombre);
    }
}
